// تم دمج محادثة Noor AI في main.js
