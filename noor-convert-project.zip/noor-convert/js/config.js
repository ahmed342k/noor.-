window.NOOR_CONFIG = {
  backendBase: 'http://localhost:3000',
  siteName: 'noor.com',
  instagram: 'https://www.instagram.com/_1w8z?igsh=N2ZvY2FreHhmNWMz',
  telegram: 'https://t.me/i_izd',
  email: 'ohkvchnjvbnb@gmail.com'
};
