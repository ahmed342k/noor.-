import express from 'express';
import cors from 'cors';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const upload = multer({ dest: path.join(__dirname, 'uploads') });
const dataDir = path.join(__dirname, 'data');
const publicDir = path.join(__dirname, 'generated');
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(publicDir, { recursive: true });
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use('/generated', express.static(publicDir));

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'noor-backend' }));

app.post('/api/chat', (req, res) => {
  const message = String(req.body?.message || '').toLowerCase();
  let reply = 'Tell me the file type and the result you want.';
  if (message.includes('pdf') && (message.includes('word') || message.includes('docx'))) reply = 'Use PDF → DOCX. If your PDF is image-only, you will need OCR in a stronger backend later.';
  else if (message.includes('image') || message.includes('jpg') || message.includes('png') || message.includes('صورة')) reply = 'For images, use PNG → JPG, Image → WebP, Compress Image, or JPG → PDF.';
  else if (message.includes('premium') || message.includes('اشتراك')) reply = 'Premium is stored locally per signed-in user in this project. For real billing, connect a secure payment gateway.';
  else if (message.includes('scan') || message.includes('فحص')) reply = 'The current project checks suspicious extensions and basic metadata. Deep malware scanning would need dedicated services.';
  res.json({ reply });
});

app.post('/api/contact', (req, res) => {
  const file = path.join(dataDir, 'contacts.json');
  const list = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : [];
  list.unshift({ ...req.body, time: new Date().toISOString() });
  fs.writeFileSync(file, JSON.stringify(list, null, 2));
  res.json({ ok: true });
});

app.post('/api/convert', upload.array('files'), (req, res) => {
  const tool = String(req.body?.tool || 'generic');
  const files = (req.files || []).map((f, idx) => {
    const outName = `${path.parse(f.originalname).name}_${tool}_${idx}.txt`;
    const outPath = path.join(publicDir, outName);
    const content = `Noor Convert\nTool: ${tool}\nOriginal: ${f.originalname}\nSize: ${f.size} bytes\nTime: ${new Date().toISOString()}\n\nThis is a backend demo output for the selected tool.`;
    fs.writeFileSync(outPath, content, 'utf8');
    return {
      name: f.originalname,
      type: f.mimetype,
      size: `${(f.size / 1024).toFixed(1)}KB`,
      outputName: outName,
      url: `http://localhost:3000/generated/${outName}`
    };
  });
  res.json({ ok: true, tool, files });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Noor backend running on http://localhost:${PORT}`));
